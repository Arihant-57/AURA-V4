"""
AURA V4 — Functional execution engine.
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys
from pathlib import Path

from ..config import get_settings, resolve_workspace
from ..core import McpHub, SessionMemory, ResultCache
from ..core.providers import ProviderFactory
from .loop import run_agent_loop


def parse_args():
    parser = argparse.ArgumentParser(description="AURA V4 AI Agent")
    parser.add_argument("--workspace", "-w", type=str, help="Workspace path")
    parser.add_argument("--model", "-m", type=str, help="Model name override")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    parser.add_argument("--selftest", action="store_true", help="Run sanity check")
    return parser.parse_args()


async def main():
    args = parse_args()

    if args.selftest:
        print("Self-test: V4 structure check complete.")
        return

    try:
        workspace_path = resolve_workspace(args.workspace)
    except ValueError as e:
        print(f"Error: {e}")
        sys.exit(1)

    print(f"AURA V4: Working on {workspace_path}")

    hub = McpHub(workspace_path)
    await hub.start()

    provider = ProviderFactory.create_ollama(model=args.model)
    if not provider.is_model_available():
        print(f"Warning: Model {provider.model} might not be pulled in Ollama.")

    memory = SessionMemory()
    cache = ResultCache(ttl_seconds=300)

    print("Commands: 'exit' to quit, 'reset' to clear session")
    try:
        while True:
            try:
                task = input("\nYou: ").strip()
            except (KeyboardInterrupt, EOFError):
                break

            if task.lower() in ("exit", "quit"):
                print("\nExiting AURA.")
                break
            if task.lower() == "reset":
                memory.clear()
                cache.clear()
                print("Session memory and cache cleared.")
                continue
            if not task:
                continue

            print(f"\n[Thinking...]")
            answer = await run_agent_loop(task, provider, hub, memory, cache)
            # Handle Unicode on Windows
            try:
                print(f"\nAURA: {answer}")
            except UnicodeEncodeError:
                # Replace unencodable chars
                safe_answer = answer.encode('ascii', 'replace').decode('ascii')
                print(f"\nAURA: {safe_answer}")
    finally:
        await hub.close()


if __name__ == "__main__":
    asyncio.run(main())
