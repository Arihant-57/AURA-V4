"""
Agent Execution Loop for AURA V4.

Coordinates:
- Intent scoping
- MCP tool discovery/discovery
- Tool execution boundary (active tools)
- Result sanitization
- Multi-turn model conversation
"""

from __future__ import annotations

import asyncio
import json
import time
from typing import Any

from ..config import get_settings
from ..core import (
    McpHub, SessionMemory, ResultCache, TaskScope,
    select_active_tools, check_path_policy, sanitize_tool_result,
    mcp_tool_to_ollama, mcp_result_to_text, validate_arguments
)
from ..core.providers import OllamaProvider


async def execute_tool_call(
    name: str,
    arguments: dict,
    step: int,
    *,
    active_tool_names: set[str],
    hub: McpHub,
    cache: ResultCache,
    memory: SessionMemory,
    scope: TaskScope,
) -> tuple[str, dict]:
    """Execute a single MCP tool call with policy checks."""
    meta = {"duplicate": False, "blocked": False, "cache_hit": False, "duration": 0.0, "error": False}

    # 1. Boundary check
    if name not in active_tool_names:
        meta["error"] = True
        return f"MCP ERROR: tool '{name}' not permitted.", meta

    # 2. Path policy
    blocked = check_path_policy(name, arguments, scope)
    if blocked:
        meta["blocked"] = True
        return blocked, meta

    # 3. Cache check
    signature = (name, json.dumps(arguments, sort_keys=True))
    hit = cache.get(signature)
    if hit:
        meta["cache_hit"] = True
        return hit, meta

    # 4. Schema validation
    schema = hub.tool_schemas.get(name)
    problem = validate_arguments(schema, arguments)
    if problem:
        meta["error"] = True
        return problem, meta

    # 5. Execution
    client = hub.tool_clients.get(name)
    start = time.perf_counter()
    try:
        result = await asyncio.wait_for(client.call_tool(name, arguments), timeout=30)
        text = mcp_result_to_text(result)
    except Exception as e:
        text = f"MCP TOOL ERROR: {e}"
        meta["error"] = True

    meta["duration"] = time.perf_counter() - start

    # 6. Sanitize and Cache
    sanitized = sanitize_tool_result(name, text, scope.prompt_lower, scope)
    cache.put(signature, sanitized)
    if name == "read_file":
        memory.note_file(arguments.get("path", ""))
    elif name == "list_directory":
        memory.note_dir(arguments.get("path", "."))

    return sanitized, meta


async def run_agent_loop(
    task: str,
    provider: OllamaProvider,
    hub: McpHub,
    memory: SessionMemory,
    cache: ResultCache
) -> str:
    """The main reasoning loop."""
    settings = get_settings()
    scope = TaskScope(task)

    # Prepare tools
    all_tools = list(hub.tools.values())
    active_tools = select_active_tools(all_tools, scope)
    active_tool_names = {t.name for t in active_tools}
    ollama_tools = [mcp_tool_to_ollama(t, scope) for t in active_tools]

    system_prompt = (
        "You are a coding assistant that MUST use tools to answer questions about the workspace.\n"
        "Available tools: " + ", ".join(active_tool_names) + ".\n"
        "When asked about files, use list_directory and read_file.\n"
        "When asked about Git, use git_* tools.\n"
        "Call tools via the tool-calling interface. Do not write tool calls as text."
    )

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": task}
    ]

    for step in range(settings.agent.max_steps):
        response = await provider.chat(messages, tools=ollama_tools)
        msg = response.message
        messages.append({"role": msg.role, "content": msg.content or "", "tool_calls": msg.tool_calls})

        has_tool_calls = msg.tool_calls and len(msg.tool_calls) > 0

        if has_tool_calls:
            # Execute tools in parallel
            tool_calls = []
            for tc in msg.tool_calls:
                func = getattr(tc, "function", None)
                if not func:
                    continue
                name = getattr(func, "name", "")
                args = getattr(func, "arguments", {})
                if isinstance(args, str):
                    try:
                        args = json.loads(args) if args.strip() else {}
                    except json.JSONDecodeError:
                        args = {}
                elif not isinstance(args, dict):
                    args = {}
                if name:
                    tool_calls.append((name, args))

            results = await asyncio.gather(*(
                execute_tool_call(
                    name, args, step,
                    active_tool_names=active_tool_names, hub=hub, cache=cache,
                    memory=memory, scope=scope
                ) for name, args in tool_calls
            ))

            for (name, args), (res_text, meta) in zip(tool_calls, results):
                messages.append({
                    "role": "tool",
                    "content": res_text,
                    "name": name
                })
        else:
            # No tool calls - provide final answer
            answer = msg.content or "(no answer)"
            if not answer.strip() or answer == "(no answer)":
                # Force a final answer using available evidence
                return await _force_answer_from_evidence(messages, provider, scope)
            return answer

    return "Maximum steps reached without final answer."


async def _force_answer_from_evidence(
    messages: list, provider: OllamaProvider, scope: TaskScope
) -> str:
    """Generate answer from gathered tool results when model gives no response."""
    # Extract tool results
    tool_results = [m for m in messages if m.get("role") == "tool"]
    if not tool_results:
        return "I have no information to answer this question."

    evidence = []
    for m in tool_results:
        evidence.append(f"[{m.get('name')}] {m.get('content', '')[:500]}")

    evidence_text = "\n".join(evidence)

    # Try to synthesize answer
    try:
        response = await provider.chat([{
            "role": "user",
            "content": f"Based on the following evidence, answer the query:\n{evidence_text}"
        }])
        return response.message.content or "(no answer)"
    except Exception:
        return f"Based on tool results:\n{evidence_text}"