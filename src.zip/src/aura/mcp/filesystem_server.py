"""
AURA Filesystem MCP Server (read-only)

Provides read-only filesystem access restricted to a single workspace.

The workspace is resolved from the AURA_WORKSPACE environment variable
or the --workspace CLI argument passed by the host agent. There is NO
hardcoded repository fallback: an unconfigured server refuses to start
rather than silently defaulting to a specific project.

Path safety:
    - Relative paths only (absolute paths rejected).
    - No '..' components (directory traversal rejected).
    - Resolved target must remain inside the workspace, even after
      symlink resolution (symlink escape rejected).
    - Unicode NFKC normalisation defeats homoglyph / bidi tricks.
"""

from __future__ import annotations

import os
import sys
import unicodedata
from pathlib import Path, PureWindowsPath

from mcp.server import MCPServer


# ============================================================
# WORKSPACE CONFIGURATION
# ============================================================

def _get_workspace() -> Path:
    """
    Resolve the workspace from the environment.

    Raises ValueError if no workspace is configured. There is no
    hardcoded repository fallback.
    """
    workspace_env = os.environ.get("AURA_WORKSPACE")
    if not workspace_env:
        raise ValueError(
            "AURA_WORKSPACE is not set. The filesystem server cannot "
            "start without an explicit workspace."
        )
    return Path(workspace_env).resolve(strict=False)


WORKSPACE = _get_workspace()

mcp = MCPServer("AURA Filesystem Server")


# ============================================================
# SAFE PATH
# ============================================================

def safe_path(path: str) -> Path:
    """
    Resolve a relative path while preventing workspace escape.

    Rejects:
        - Empty / non-string paths
        - Absolute paths and Windows drive paths
        - '..' components
        - Trailing whitespace or dots in components
        - Targets that resolve outside the workspace, including
          through symlinks

    Args:
        path: Repository-relative path

    Returns:
        Resolved absolute Path inside the workspace

    Raises:
        ValueError: If the path escapes the workspace
    """
    if not isinstance(path, str) or not path.strip():
        raise ValueError("Invalid path.")

    normalised = unicodedata.normalize("NFKC", path)
    normalised = normalised.replace("\\", "/")

    windows_path = PureWindowsPath(normalised)

    if windows_path.is_absolute() or windows_path.drive:
        raise ValueError("Absolute paths are not allowed.")

    components = normalised.split("/")

    for component in components:
        if component in {"", "."}:
            continue
        if component == "..":
            raise ValueError(
                "Access outside the project workspace is not allowed."
            )
        if component != component.rstrip():
            raise ValueError("Invalid path component.")
        if component != component.rstrip("."):
            raise ValueError("Invalid path component.")
        if component.strip(".") == "":
            raise ValueError("Invalid path component.")

    # Re-resolve the workspace in case it changed at runtime.
    workspace = _get_workspace()
    target = (workspace / Path(normalised)).resolve(strict=False)

    try:
        target.relative_to(workspace)
    except ValueError:
        raise ValueError(
            "Access outside the project workspace is not allowed."
        )

    return target


# ============================================================
# READ FILE
# ============================================================

@mcp.tool()
def read_file(path: str) -> str:
    """Read a UTF-8 text file inside the workspace."""

    target = safe_path(path)

    if not target.exists():
        return f"ERROR: File does not exist: {path}"

    if not target.is_file():
        return f"ERROR: Not a file: {path}"

    try:
        content = target.read_text(
            encoding="utf-8",
            errors="replace",
        )
    except Exception as exc:
        return f"ERROR reading file: {exc}"

    # Prevent enormous model context.
    if len(content) > 10000:
        content = content[:10000]
        content += "\n\n[TRUNCATED: file exceeds 10,000 characters]"

    return content


# ============================================================
# LIST DIRECTORY
# ============================================================

@mcp.tool()
def list_directory(path: str = ".") -> str:
    """List files and directories inside the workspace."""

    target = safe_path(path)

    if not target.exists():
        return f"ERROR: Directory does not exist: {path}"

    if not target.is_dir():
        return f"ERROR: Not a directory: {path}"

    try:
        entries = sorted(
            target.iterdir(),
            key=lambda p: (not p.is_dir(), p.name.lower()),
        )
    except Exception as exc:
        return f"ERROR listing directory: {exc}"

    lines = []

    for entry in entries[:50]:
        if entry.is_dir():
            lines.append(f"DIR  {entry.name}")
        else:
            lines.append(f"FILE {entry.name}")

    if len(entries) > 50:
        lines.append(
            f"\n[TRUNCATED: showing first 50 of {len(entries)} entries]"
        )

    if not lines:
        return "(empty directory)"

    return "\n".join(lines)


# ============================================================
# SEARCH FILES
# ============================================================

@mcp.tool()
def search_files(
    query: str,
    path: str = ".",
) -> str:
    """Search supported UTF-8 source files recursively inside the workspace."""

    if not isinstance(query, str) or not query.strip():
        return "ERROR: Search query cannot be empty."

    target = safe_path(path)

    if not target.exists():
        return f"ERROR: Path does not exist: {path}"

    if not target.is_dir():
        return f"ERROR: Search path is not a directory: {path}"

    query_lower = query.lower()

    supported_extensions = {
        ".txt",
        ".md",
        ".py",
        ".js",
        ".jsx",
        ".ts",
        ".tsx",
        ".json",
        ".yaml",
        ".yml",
        ".css",
        ".html",
        ".ino",
    }

    excluded_directories = {
        ".git",
        ".next",
        "node_modules",
        ".venv",
        "__pycache__",
    }

    results = []

    try:
        for file_path in target.rglob("*"):
            if not file_path.is_file():
                continue
            if file_path.suffix.lower() not in supported_extensions:
                continue
            if any(part in excluded_directories for part in file_path.parts):
                continue
            try:
                content = file_path.read_text(
                    encoding="utf-8",
                    errors="replace",
                )
            except Exception:
                continue
            for line_number, line in enumerate(
                content.splitlines(),
                start=1,
            ):
                if query_lower in line.lower():
                    relative = file_path.relative_to(WORKSPACE)
                    results.append(
                        f"{relative}:{line_number}: {line.strip()}"
                    )
                    if len(results) >= 100:
                        return "\n".join(
                            results
                        ) + "\n\n[TRUNCATED: 100 results]"
    except Exception as exc:
        return f"ERROR searching files: {exc}"

    if not results:
        return "(no matches found)"

    return "\n".join(results)


# ============================================================
# START MCP SERVER
# ============================================================

if __name__ == "__main__":
    mcp.run()