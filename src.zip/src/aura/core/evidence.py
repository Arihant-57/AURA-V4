"""
Evidence Models and Extraction logic for AURA V4.

Handles evidence item representation, prefetch read planning, and
structural source skeleton extraction.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

from .evidence_constants import (
    MANIFEST_NAMES, LOCK_FILES, PREFETCH_MAX_READS,
    PREFETCH_SKELETON_CHARS, PREFETCH_HEAD_CHARS, PREFETCH_TAIL_CHARS,
    _SOURCE_FILTER_PATTERNS
)


@dataclass
class EvidenceItem:
    """One verified observation from an MCP tool call."""
    source: str            # MCP server name, e.g. "filesystem"
    tool: str              # tool that produced it, e.g. "read_file"
    path: str              # path as actually accessed
    content: str           # observed content (or error text)
    complete: bool         # False if truncated or structurally extracted
    retrieval_method: str  # "prefetch-listing" | "prefetch-read" | "prefetch-skeleton"
    note: str = ""


def _listing_entries(text: str) -> list[str]:
    """Extract entry names from a directory listing."""
    names: list[str] = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("(") or "TRUNCATED" in stripped:
            continue
        for token in re.findall(r"[A-Za-z0-9_][A-Za-z0-9_.\-/]*", stripped):
            token = token.rstrip("/")
            if token and token not in {"FILE", "DIR"}:
                names.append(token)
    return names


def plan_prefetch_reads(listing_text: str, base_dir: str, policy: "PrefetchPolicy") -> list[str]:
    """Choose files to read from an ACTUAL listing."""
    entries = _listing_entries(listing_text)
    seen: dict[str, str] = {}
    for entry in entries:
        seen.setdefault(entry.lower(), entry)

    manifests: list[str] = []
    entrypoints: list[str] = []
    sources: list[str] = []
    for low, original in seen.items():
        base = low.rsplit("/", 1)[-1]
        if base in LOCK_FILES:
            continue
        if base in MANIFEST_NAMES or base.endswith(".csproj"):
            manifests.append(original)
        elif base in policy.entrypoint_names:
            entrypoints.append(original)
        elif policy.source_suffixes and base.endswith(policy.source_suffixes):
            sources.append(original)

    picks = manifests + entrypoints
    if not entrypoints:
        picks += sources[:2 if not manifests else 1]
    picks = picks[:PREFETCH_MAX_READS]

    prefix = "" if base_dir == "." else base_dir.rstrip("/") + "/"
    return [p if "/" in p else prefix + p for p in picks]


def extract_source_skeleton(text: str, budget: int = PREFETCH_SKELETON_CHARS) -> tuple[str, bool]:
    """Deterministic structural extraction for oversized source files."""
    if len(text) <= budget:
        return text, True
    head = text[:PREFETCH_HEAD_CHARS]
    tail = text[-PREFETCH_TAIL_CHARS:]
    signal_lines = []
    compiled = [re.compile(p, re.IGNORECASE) for p in _SOURCE_FILTER_PATTERNS]
    for i, line in enumerate(text.splitlines()):
        if line.strip() and any(r.search(line) for r in compiled):
            signal_lines.append(f"  L{i + 1}: {line.strip()[:160]}")
    skeleton = (
        f"[HEAD of file — first {PREFETCH_HEAD_CHARS} chars]\n{head}\n\n"
        f"[SIGNAL LINES — imports/exports/routes/definitions/bootstrap, "
        f"{len(signal_lines)} matched, with original line numbers]\n"
        + ("\n".join(signal_lines) if signal_lines else "(none matched)")
        + f"\n\n[TAIL of file — last {PREFETCH_TAIL_CHARS} chars]\n{tail}"
    )
    if len(skeleton) > budget:
        skeleton = skeleton[:budget] + "\n[skeleton trimmed to budget]"
    return skeleton, False


def evidence_is_sufficient(items: list[EvidenceItem]) -> bool:
    """Minimum bar for the single-synthesis path."""
    def ok(item: EvidenceItem) -> bool:
        return not item.content.startswith("MCP ") and bool(item.content.strip())

    listings = [i for i in items if i.tool == "list_directory" and ok(i)]
    reads = [i for i in items if i.tool == "read_file" and ok(i)]
    return bool(listings and reads)